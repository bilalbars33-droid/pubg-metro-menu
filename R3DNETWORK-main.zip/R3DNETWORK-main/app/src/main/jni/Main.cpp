#include <list>
#include <vector>
#include <cstring>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <numbers>

#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "dobby/dobby.h"
#include "Menu/FeatureModule.hpp"
#include "UnityResolve/UnityResolve.hpp"
#include "Includes/Utils.hpp"
#include "Includes/RemapTools.h"
#include "KittyMemory/MemoryPatch.h"
#include "Includes/ObscuredTypes.hpp"
#include "Includes/ESPManager.h"
#include "Menu/JNILoader.hpp"
#include "Menu/Setup.hpp"
#include "Hacks/Hooks.hpp"
// Target lib here
#define IL2CPP_MODULE OBFUSCATE("libil2cpp.so")

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
        OBFUSCATE("Category_💥 METRO ROYALE"),  // Sol taraftaki 1. Dikey Sekme ismi
        OBFUSCATE("1_Toggle_Turbo Kelebek"),    // 1. Sekmenin altındaki buton
        OBFUSCATE("2_Toggle_Turbo Sahte İtem"), // 1. Sekmenin altındaki ikinci buton
        OBFUSCATE("Category_⚙️ AYARLAR")         // Sol taraftaki 2. Dikey Sekme ismi
    };

    int Total_Feature = (sizeof features / sizeof features);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jobject obj, jobject context, jint featureNum, jstring featureName, jint value, jboolean boolean, jstring str) {
    
    switch (featureNum) {
        case 1: // Turbo Kelebek aktif/pasif durumu
            if (boolean) {
                // Turbo Kelebek AÇILDIĞINDA çalışacak kodlar buraya gelecek
            } else {
                // Turbo Kelebek KAPATILDIĞINDA çalışacak kodlar buraya gelecek
            }
            break;
        case 2: // Turbo Sahte İtem aktif/pasif durumu
            if (boolean) {
                // Turbo Sahte İtem AÇILDIĞINDA çalışacak kodlar buraya gelecek
            } else {
                // Turbo Sahte İtem KAPATILDIĞINDA çalışacak kodlar buraya gelecek
            }
            break;
    }
}

extern "C" JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    if (vm->GetEnv((void **) &env, JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }
    return JNI_VERSION_1_6;
}